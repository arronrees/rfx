module.exports.getProfile = async (req, res) => {
  res.render('user/profile.ejs');
};
